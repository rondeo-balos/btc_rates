# btc_rates
 a shortcode [btc_rates] that shows the current rate of Bitcoin in USD, GBP, and EUR.
